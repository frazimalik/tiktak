# admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

# # Customize the User admin panel
# class UserAdmin(admin.ModelAdmin):
#     list_display = ['username', 'email', 'is_creator', 'is_consumer']
#     list_filter = ['is_creator', 'is_consumer']
#     search_fields = ['username', 'email']
#     list_editable = ['is_creator', 'is_consumer']
    
#     # Ensure the password field is editable (useful for admin purposes)
#     fieldsets = (
#         (None, {'fields': ('username', 'email', 'password')}),
#         ('Permissions', {'fields': ('is_creator', 'is_consumer', 'groups', 'user_permissions')}),
#     )
#     add_fieldsets = (
#         (None, {'fields': ('username', 'email', 'password1', 'password2')}),
#         ('Permissions', {'fields': ('is_creator', 'is_consumer')}),
#     )

# admin.site.register(User, UserAdmin)


class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ['username', 'email', 'is_creator', 'is_consumer']
    list_filter = ['is_creator', 'is_consumer']
    search_fields = ['username', 'email']
    ordering = ['username']
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions', 'is_creator', 'is_consumer')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2', 'is_creator', 'is_consumer')
        }),
    )

admin.site.register(User, CustomUserAdmin)
