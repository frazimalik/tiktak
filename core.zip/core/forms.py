from django import forms
from .models import Video, Comment, Rating, User
from django.contrib.auth.forms import AuthenticationForm

class CreatorVideoUploadForm(forms.ModelForm):
    class Meta:
        model = Video
        fields = ['title', 'hashtags', 'video_file']

class ConsumerSignupForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']

class RatingForm(forms.ModelForm):
    class Meta:
        model = Rating
        fields = ['rating']

class CustomLoginForm(AuthenticationForm):
    class Meta:
        model = User  # Make sure you're pointing to your custom User model
        fields = ['username', 'password']
